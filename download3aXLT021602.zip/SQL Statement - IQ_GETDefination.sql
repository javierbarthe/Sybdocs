sp_iqhelp '<Object name>'

sp_helptext '<Object name>'
