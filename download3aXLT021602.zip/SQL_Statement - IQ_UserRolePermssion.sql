


1.
sp_displayrole

2.
sp_objectpermission �<username>�

3.
select * from sysrolegrants

4.
select * from sysuserauth

/* SAP note 2518909 - How to find permissions granted to users in SAP IQ */ 
