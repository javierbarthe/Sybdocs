1.
sp_iqmpxvalidate  

2.
call dbo.sp_iqmpxvalidate('show_msgs')

3.
sp_iqmpxincheartbeatinfo

4.
sp_iqmpxincstatistics   

