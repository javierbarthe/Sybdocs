sp_iqlmconfig   
