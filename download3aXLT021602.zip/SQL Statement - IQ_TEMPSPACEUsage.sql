1.
select month(now()),today(),cast(now() as time) as TIMESTAMP,substring(@@servername,1,20) as HOSTNAME,substring(DBSpaceName,1,20) as DBSPACE_NAME,Usage as PERC_USED from sp_iqdbspace() where DBSpaceName='IQ_SYSTEM_TEMP';)

2.
select Top 5 ConnHandle,  IQconnID, Name , IQCmdType,LastIQCmdTime, ConnCreateTime, NodeAddr, (TempTableSpaceKB+TempWorkSpaceKB) as TempSpaceUsed from sp_iqconnection() order by TempSpaceUsed desc 