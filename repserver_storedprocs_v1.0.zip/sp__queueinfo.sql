create proc sp__queueinfo
as
set nocount on
declare @total varchar(10),
        @free varchar(10),
        @freeperc varchar(10),
        @repserver varchar(30),
        @datetime varchar(20)

select @repserver = charvalue from rs_config where optionname = 'oserver'

select @datetime = convert(varchar(10),getdate(),101)+" "+convert(varchar(8),getdate(),8),
       @total = convert(varchar(10),sum(num_segs)),
       @free = convert(varchar(10),sum(num_segs)-sum(allocated_segs)),
       @freeperc = convert(varchar(12),convert(numeric(10,2),
                (convert(real,(sum(num_segs)-sum(allocated_segs))) / convert(real,sum(num_segs)))*100 ))

from rs_diskpartitions

print "Stable Queue Information for %1! at %2!",@repserver, @datetime
print "Total Partition Size = %1!MB, Space Remaining = %2!MB (%3!%%)",@total,@free,@freeperc


select rs.q_number,rs.q_type, ( select dsname+'.'+dbname
                                from rs_databases
                where dbid = rs.q_number
                                and rs.q_number != 0) queue_name, count(*) "size(MB)"
from rs_segments rs
group by q_number,q_type
having q_number != 0
order by count(*) desc 
go
